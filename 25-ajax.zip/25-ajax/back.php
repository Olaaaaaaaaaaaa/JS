<?php

$langue = $_POST["langue"];

if ($langue == "FR") {
    $reponse = "Bonjour";
}
if ($langue == "EN") {
    $reponse = "Hello";
}

echo "$reponse";
