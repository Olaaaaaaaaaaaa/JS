$.post("back.php", { langue: "EN" }, function (reponse) {
    console.log(reponse);
});